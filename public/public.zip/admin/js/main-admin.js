/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 170);
/******/ })
/************************************************************************/
/******/ ({

/***/ 170:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(171);


/***/ }),

/***/ 171:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_app__ = __webpack_require__(172);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_app___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_app__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_app_menu__ = __webpack_require__(173);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_app_menu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_app_menu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_login__ = __webpack_require__(174);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_login___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__components_login__);




// Announcement Form


$("#AnnouncementForm").validate({
    rules: {
        announcementTitle: {
            required: true

        },
        announcementText: {
            required: true,
            minlength: 5,
            maxlength: 1000

        }
    },
    messages: {
        announcementTitle: {
            required: "Announcement Title is required"
        },

        announcementText: {
            required: "Announcement Text is required"
        }

    },

    // SignUp Submit Handler
    submitHandler: function submitHandler(form, e) {

        e.preventDefault();

        var url = "path/to/your/script.php"; // the script where you handle the form input.

        var announcementTitle = $("#announcementTitle").val();
        var announcementText = $("#announcementText").val();

        swal({
            title: 'Are you sure you want to publish this announcement?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Publish'
        }).then(function (result) {
            if (result.value) {

                $.ajax({
                    type: "POST",
                    url: url,
                    beforeSend: function beforeSend() {

                        $('.ajax-loading').css('display', 'block');
                    },
                    complete: function complete() {

                        $('.ajax-loading').css('display', 'none');
                    },
                    success: function success(data) {},
                    error: function error(data) {

                        Swal({
                            title: "Announcement Successfully published To All Zidni's Users",
                            imageUrl: 'http://placehold.it/150x150',
                            imageWidth: 150,
                            imageHeight: 150,
                            imageAlt: 'Zidni Logo',
                            animation: true,
                            showCancelButton: false,
                            confirmButtonColor: '#f1dd7e',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Great',
                            allowOutsideClick: false,
                            allowEscapeKey: false,
                            width: '60rem',
                            customClass: 'welcomeAlertMessage'
                        }).then(function (result) {
                            if (result.value) {

                                $('#announcement').modal('hide');

                                var _announcementTitle = $("#announcementTitle").val('');
                                var _announcementText = $("#announcementText").val('');
                            }
                        });
                    }

                });
            }
        });
    }

});

/***/ }),

/***/ 172:
/***/ (function(module, exports) {

/*=========================================================================================

  Item Name: Zidni App
  Version: 1.0
==========================================================================================*/

(function (window, document, $) {
    'use strict';

    var $html = $('html');
    var $body = $('body');

    $(window).on('load', function () {
        var rtl;
        if ($('html').data('textdirection') == 'rtl') {
            rtl = true;
        }

        setTimeout(function () {
            $html.removeClass('loading').addClass('loaded');
        }, 1200);

        $.app.menu.init();

        // Navigation configurations
        var config = {
            speed: 300 // set speed to expand / collpase menu
        };
        if ($.app.nav.initialized === false) {
            $.app.nav.init(config);
        }

        Unison.on('change', function (bp) {
            $.app.menu.change();
        });

        // Tooltip Initialization
        $('[data-toggle="tooltip"]').tooltip({
            container: 'body'
        });

        // Collapsible Card
        $('a[data-action="collapse"]').on('click', function (e) {
            e.preventDefault();
            $(this).closest('.card').children('.card-body').collapse('toggle');
            $(this).closest('.card').find('[data-action="collapse"] i').toggleClass('fa-minus fa-plus');
        });

        // Toggle fullscreen
        $('a[data-action="expand"]').on('click', function (e) {
            e.preventDefault();
            $(this).closest('.card').find('[data-action="expand"] i').toggleClass('icon-expand2 icon-contract');
            $(this).closest('.card').toggleClass('card-fullscreen');
        });

        //  Notifications & messages scrollable
        if ($('.scrollable-container').length > 0) {
            $('.scrollable-container').perfectScrollbar({
                theme: "dark"
            });
        }

        // Reload Card
        $('a[data-action="reload"]').on('click', function () {
            var block_ele = $(this).closest('.card');

            // Block Element
            block_ele.block({
                message: '<div class="icon-spinner9 icon-spin icon-lg"></div>',
                timeout: 2000, //unblock after 2 seconds
                overlayCSS: {
                    backgroundColor: '#FFF',
                    cursor: 'wait'
                },
                css: {
                    border: 0,
                    padding: 0,
                    backgroundColor: 'none'
                }
            });
        });

        // Close Card
        $('a[data-action="close"]').on('click', function () {
            $(this).closest('.card').removeClass().slideUp('fast');
        });

        // Match the height of each card in a row
        setTimeout(function () {
            $('.row.match-height').each(function () {
                $(this).find('.card').not('.card .card').matchHeight(); // Not .card .card prevents collapsible cards from taking height
            });
        }, 500);

        $('.card .heading-elements a[data-action="collapse"]').on('click', function () {
            var $this = $(this),
                card = $this.closest('.card');
            var cardHeight;

            if (parseInt(card[0].style.height, 10) > 0) {
                cardHeight = card.css('height');
                card.css('height', '').attr('data-height', cardHeight);
            } else {
                if (card.data('height')) {
                    cardHeight = card.data('height');
                    card.css('height', cardHeight).attr('data-height', '');
                }
            }
        });

        // Add open class to parent list item if subitem is active except compact menu
        var menuType = $body.data('menu');
        if (menuType != 'vertical-compact-menu' && menuType != 'horizontal-menu' && menuType != 'horizontal-top-icon-menu') {
            $(".main-menu-content").find('li.active').parents('li').addClass('open');
        }
        if (menuType == 'vertical-compact-menu' || menuType == 'horizontal-menu' || menuType == 'horizontal-top-icon-menu') {
            $(".main-menu-content").find('li.active').parents('li:not(.nav-item)').addClass('open');
            $(".main-menu-content").find('li.active').parents('li').addClass('active');
        }

        /*
        //card heading actions buttons small screen support
        $(".heading-elements-toggle").on("click", function () {
            $(this).parent().children(".heading-elements").toggleClass("visible");
        });
        
        */

        //  Dynamic height for the chartjs div for the chart animations to work
        var chartjsDiv = $('.chartjs'),
            canvasHeight = chartjsDiv.children('canvas').attr('height');
        chartjsDiv.css('height', canvasHeight);

        if ($('body').hasClass('boxed-layout')) {
            if ($('body').hasClass('vertical-overlay-menu') || $('body').hasClass('vertical-compact-menu')) {
                var menuWidth = $('.main-menu').width();
                var contentPosition = $('.app-content').position().left;
                var menuPositionAdjust = contentPosition - menuWidth;
                if ($('body').hasClass('menu-flipped')) {
                    $('.main-menu').css('right', menuPositionAdjust + 'px');
                } else {
                    $('.main-menu').css('left', menuPositionAdjust + 'px');
                }
            }
        }
    });

    $(document).on('click', '.menu-toggle', function (e) {
        e.preventDefault();

        // Toggle menu
        $.app.menu.toggle();

        return false;
    });

    $(document).on('click', '.open-navbar-container', function (e) {

        var currentBreakpoint = Unison.fetch.now();

        // Init drilldown on small screen
        $.app.menu.drillDownMenu(currentBreakpoint.name);

        // return false;
    });

    $(document).on('click', '.main-menu-footer .footer-toggle', function (e) {
        e.preventDefault();
        $(this).find('i').toggleClass('pe-is-i-angle-down pe-is-i-angle-up');
        $('.main-menu-footer').toggleClass('footer-close footer-open');
        return false;
    });

    // Add Children Class
    $('.navigation').find('li').has('ul').addClass('has-sub');

    $('.carousel').carousel({
        interval: 2000
    });

    // Page full screen
    $('.nav-link-expand').on('click', function (e) {
        if (typeof screenfull != 'undefined') {
            if (screenfull.enabled) {
                screenfull.toggle();
            }
        }
    });
    if (typeof screenfull != 'undefined') {
        if (screenfull.enabled) {
            $(document).on(screenfull.raw.fullscreenchange, function () {
                if (screenfull.isFullscreen) {
                    $('.nav-link-expand').find('i').toggleClass('icon-contract icon-expand2');
                } else {
                    $('.nav-link-expand').find('i').toggleClass('icon-expand2 icon-contract');
                }
            });
        }
    }

    // Update manual scroller when window is resized
    $(window).resize(function () {
        $.app.menu.manualScroller.updateHeight();
    });

    // TODO : Tabs dropdown fix, remove this code once fixed in bootstrap 4.
    $('.nav.nav-tabs a.dropdown-item', '.nav.nav-tabs a.dropdown-item').on('click', function () {
        var $this = $(this),
            href = $this.attr('href');
        var tabs = $this.closest('.nav');
        tabs.find('.nav-link').removeClass('active');
        $this.closest('.nav-item').find('.nav-link').addClass('active');
        $this.closest('.dropdown-menu').find('.dropdown-item').removeClass('active');
        $this.addClass('active');
        tabs.next().find(href).siblings('.tab-pane').removeClass('active in').attr('aria-expanded', false);
        $(href).addClass('active in').attr('aria-expanded', 'true');
    });

    $('#sidebar-page-navigation').on('click', 'a.nav-link', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var $this = $(this),
            href = $this.attr('href');
        var offset = $(href).offset();
        var scrollto = offset.top - 80; // minus fixed header height
        $('html, body').animate({
            scrollTop: scrollto
        }, 0);
        setTimeout(function () {
            $this.parent('.nav-item').siblings('.nav-item').children('.nav-link').removeClass('active');
            $this.addClass('active');
        }, 100);
    });

    var url = window.location.pathname,
        urlRegExp = new RegExp(url.replace(/\/$/, '') + "$"); // create regexp to match current url pathname and remove trailing slash if present as it could collide with the link in navigation in case trailing slash wasn't present there
    // now grab every link from the navigation
    $('.nav-item a').each(function () {
        // and test its normalized href against the url pathname regexp
        if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
            $(this).parent().addClass('active');
        }
    });
})(window, document, jQuery);

/***/ }),

/***/ 173:
/***/ (function(module, exports) {

/*=========================================================================================
  Item Name: Zidni App
  Version: 1.0
==========================================================================================*/

(function (window, document, $) {

    'use strict';

    $.app = $.app || {};

    var $body = $('body');
    var $window = $(window);
    var menuWrapper_el = $('div[data-menu="menu-wrapper"]').html();
    var menuWrapperClasses = $('div[data-menu="menu-wrapper"]').attr('class');

    // Main menu
    $.app.menu = {
        expanded: null,
        collapsed: null,
        hidden: null,
        container: null,
        horizontalMenu: false,

        manualScroller: {
            obj: null,

            init: function init() {
                var scroll_theme = $('.main-menu').hasClass('menu-dark') ? 'light' : 'dark';
                this.obj = $(".main-menu-content").perfectScrollbar({
                    suppressScrollX: true,
                    theme: scroll_theme
                });
            },

            update: function update() {
                if (this.obj) {
                    // Scroll to currently active menu on page load if data-scroll-to-active is true
                    if ($('.main-menu').data('scroll-to-active') === true) {
                        var position;
                        if ($(".main-menu-content").find('li.active').parents('li').length > 0) {
                            position = $(".main-menu-content").find('li.active').parents('li').last().position();
                        } else {
                            position = $(".main-menu-content").find('li.active').position();
                        }
                        setTimeout(function () {
                            // $.app.menu.container.scrollTop(position.top);
                            $.app.menu.container.stop().animate({
                                scrollTop: position.top
                            }, 300);
                            $('.main-menu').data('scroll-to-active', 'false');
                        }, 300);
                    }
                    $(".main-menu-content").perfectScrollbar('update');
                }
            },

            enable: function enable() {
                this.init();
            },

            disable: function disable() {
                if (this.obj) {
                    $('.main-menu-content').perfectScrollbar('destroy');
                }
            },

            updateHeight: function updateHeight() {
                if (($body.data('menu') == 'vertical-menu' || $body.data('menu') == 'vertical-overlay-menu') && $('.main-menu').hasClass('menu-fixed')) {
                    $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height() - $('.main-menu-header').outerHeight() - $('.main-menu-footer').outerHeight());
                    this.update();
                }
            }
        },

        init: function init() {
            if ($('.main-menu-content').length > 0) {
                this.container = $('.main-menu-content');

                var menuObj = this;

                this.change();
            } else {
                // For 1 column layout menu won't be initialized so initiate drill down for mega menu

                // Drill down menu
                // ------------------------------
                this.drillDownMenu();
            }
        },

        drillDownMenu: function drillDownMenu(screenSize) {
            if ($('.drilldown-menu').length) {
                if (screenSize == 'sm' || screenSize == 'xs') {
                    if ($('#navbar-mobile').attr('aria-expanded') == 'true') {

                        $('.drilldown-menu').slidingMenu({
                            backLabel: true
                        });
                    }
                } else {
                    $('.drilldown-menu').slidingMenu({
                        backLabel: true
                    });
                }
            }
        },

        change: function change() {
            var currentBreakpoint = Unison.fetch.now(); // Current Breakpoint

            this.reset();

            var menuType = $body.data('menu');

            if (currentBreakpoint) {
                switch (currentBreakpoint.name) {
                    case 'xl':
                    case 'lg':
                        if (menuType === 'vertical-overlay-menu') {
                            this.hide();
                        } else if (menuType === 'vertical-compact-menu') {
                            this.open();
                        } else {
                            this.expand();
                        }
                        break;
                    case 'md':
                        if (menuType === 'vertical-overlay-menu' || menuType === 'vertical-mmenu') {
                            this.hide();
                        } else if (menuType === 'vertical-compact-menu') {
                            this.open();
                        } else {
                            this.collapse();
                        }
                        break;
                    case 'sm':
                        this.hide();
                        break;
                    case 'xs':
                        this.hide();
                        break;
                }
            }

            // On the small and extra small screen make them overlay menu
            if (menuType === 'vertical-menu' || menuType === 'vertical-compact-menu' || menuType === 'vertical-content-menu') {
                this.toOverlayMenu(currentBreakpoint.name);
            }

            // Initialize drill down menu for vertical layouts, for horizontal layouts drilldown menu is intitialized in changemenu function
            if (menuType != 'horizontal-menu' && menuType != 'horizontal-top-icon-menu') {
                // Drill down menu
                // ------------------------------
                this.drillDownMenu(currentBreakpoint.name);
            }

            // Dropdown submenu on large screen on hover For Large screen only
            // ---------------------------------------------------------------
            if (currentBreakpoint.name == 'xl') {
                $('body[data-open="hover"] .dropdown').on('mouseenter', function () {
                    if (!$(this).hasClass('open')) {
                        $(this).addClass('open');
                    } else {
                        $(this).removeClass('open');
                    }
                }).on('mouseleave', function (event) {
                    $(this).removeClass('open');
                });

                $('body[data-open="hover"] .dropdown a').on('click', function (e) {
                    if (menuType == 'horizontal-menu' || menuType == 'horizontal-top-icon-menu') {
                        var $this = $(this);
                        if ($this.hasClass('dropdown-toggle')) {
                            return false;
                        }
                    }
                });
            }

            // Added data attribute brand-center for navbar-brand-center
            // TODO:AJ: Shift this feature in JADE.
            if ($('.header-navbar').hasClass('navbar-brand-center')) {
                $('.header-navbar').attr('data-nav', 'brand-center');
            }
            if (currentBreakpoint.name == 'sm' || currentBreakpoint.name == 'xs') {
                $('.header-navbar[data-nav=brand-center]').removeClass('navbar-brand-center');
            } else {
                $('.header-navbar[data-nav=brand-center]').addClass('navbar-brand-center');
            }

            // Dropdown submenu on small screen on click
            // --------------------------------------------------
            $('ul.dropdown-menu [data-toggle=dropdown]').on('click', function (event) {
                if ($(this).siblings('ul.dropdown-menu').length > 0) {
                    event.preventDefault();
                }
                event.stopPropagation();
                $(this).parent().siblings().removeClass('open');
                $(this).parent().toggleClass('open');
            });
        },

        changeLogo: function changeLogo(menuType) {
            var logo = $('.brand-logo');
            if (menuType == 'expand') {
                logo.attr('src', logo.data('expand'));
            } else {
                logo.attr('src', logo.data('collapse'));
            }
        },

        transit: function transit(callback1, callback2) {
            var menuObj = this;
            $body.addClass('changing-menu');

            callback1.call(menuObj);

            if ($body.hasClass('vertical-layout')) {
                if ($body.hasClass('menu-open') || $body.hasClass('menu-expanded')) {
                    $('.menu-toggle').addClass('is-active');

                    // Show menu header search when menu is normally visible
                    if ($body.data('menu') === 'vertical-menu' || $body.data('menu') === 'vertical-content-menu') {
                        if ($('.main-menu-header')) {
                            $('.main-menu-header').show();
                        }
                    }
                } else {
                    $('.menu-toggle').removeClass('is-active');

                    // Hide menu header search when only menu icons are visible
                    if ($body.data('menu') === 'vertical-menu' || $body.data('menu') === 'vertical-content-menu') {
                        if ($('.main-menu-header')) {
                            $('.main-menu-header').hide();
                        }
                    }
                }
            }

            setTimeout(function () {
                callback2.call(menuObj);
                $body.removeClass('changing-menu');

                menuObj.update();
            }, 500);
        },

        open: function open() {
            if ($body.is('.vertical-mmenu')) {
                this.mMenu.enable();
            }
            this.transit(function () {
                $body.removeClass('menu-hide menu-collapsed').addClass('menu-open');
                this.hidden = false;
                this.expanded = true;
            }, function () {
                if (!$('.main-menu').hasClass('menu-native-scroll') && !$body.is('.vertical-mmenu') && $('.main-menu').hasClass('menu-fixed')) {
                    this.manualScroller.enable();
                    $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height() - $('.main-menu-header').outerHeight() - $('.main-menu-footer').outerHeight());
                    // this.manualScroller.update();
                }
            });
        },

        hide: function hide() {
            if ($body.is('.vertical-mmenu')) {
                this.mMenu.disable();
            }

            this.transit(function () {
                $body.removeClass('menu-open menu-expanded').addClass('menu-hide');
                this.hidden = true;
                this.expanded = false;
            }, function () {
                if (!$('.main-menu').hasClass('menu-native-scroll') && !$body.is('.vertical-mmenu') && $('.main-menu').hasClass('menu-fixed')) {
                    this.manualScroller.enable();
                }
            });
        },

        expand: function expand() {
            if (this.expanded === false) {
                if ($body.data('menu') == 'vertical-menu') {
                    this.changeLogo('expand');
                }
                this.transit(function () {
                    $body.removeClass('menu-collapsed').addClass('menu-expanded');
                    this.collapsed = false;
                    this.expanded = true;
                }, function () {

                    if ($body.is('.vertical-mmenu')) {
                        this.mMenu.enable();
                    } else if ($('.main-menu').hasClass('menu-native-scroll') || $body.data('menu') == 'vertical-mmenu' || $body.data('menu') == 'horizontal-menu' || $body.data('menu') == 'horizontal-top-icon-menu') {
                        this.manualScroller.disable();
                    } else {
                        if ($('.main-menu').hasClass('menu-fixed')) this.manualScroller.enable();
                    }

                    if ($body.data('menu') == 'vertical-menu' && $('.main-menu').hasClass('menu-fixed')) {
                        $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height() - $('.main-menu-header').outerHeight() - $('.main-menu-footer').outerHeight());
                        // this.manualScroller.update();
                    }
                });
            }
        },

        collapse: function collapse() {
            if (this.collapsed === false) {
                if ($body.data('menu') == 'vertical-menu') {
                    this.changeLogo('collapse');
                }
                this.transit(function () {
                    $body.removeClass('menu-expanded').addClass('menu-collapsed');
                    this.collapsed = true;
                    this.expanded = false;
                }, function () {

                    if ($body.data('menu') == 'vertical-content-menu') {
                        this.manualScroller.disable();
                    }

                    if (($body.data('menu') == 'horizontal-menu' || $body.data('menu') == 'horizontal-top-icon-menu') && $body.hasClass('vertical-overlay-menu')) {
                        if ($('.main-menu').hasClass('menu-fixed')) this.manualScroller.enable();
                    }
                    if ($body.data('menu') == 'vertical-menu' && $('.main-menu').hasClass('menu-fixed')) {
                        $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height());
                        // this.manualScroller.update();
                    }
                });
            }
        },

        toOverlayMenu: function toOverlayMenu(screen) {
            var menu = $body.data('menu');
            if (screen == 'sm' || screen == 'xs') {
                if ($body.hasClass(menu)) {
                    $body.removeClass(menu).addClass('vertical-overlay-menu');
                }
                if (menu == 'vertical-content-menu') {
                    $('.main-menu').addClass('menu-fixed');
                }
            } else {
                if ($body.hasClass('vertical-overlay-menu')) {
                    $body.removeClass('vertical-overlay-menu').addClass(menu);
                }
                if (menu == 'vertical-content-menu') {
                    $('.main-menu').removeClass('menu-fixed');
                }
            }
        },

        toggle: function toggle() {
            var currentBreakpoint = Unison.fetch.now(); // Current Breakpoint
            var collapsed = this.collapsed;
            var expanded = this.expanded;
            var hidden = this.hidden;
            var menu = $body.data('menu');

            switch (currentBreakpoint.name) {
                case 'xl':
                case 'lg':
                case 'md':
                    if (expanded === true) {
                        if (menu == 'vertical-compact-menu' || menu == 'vertical-mmenu' || menu == 'vertical-overlay-menu') {
                            this.hide();
                        } else {
                            this.collapse();
                        }
                    } else {
                        if (menu == 'vertical-compact-menu' || menu == 'vertical-mmenu' || menu == 'vertical-overlay-menu') {
                            this.open();
                        } else {
                            this.expand();
                        }
                    }
                    break;
                case 'sm':
                    if (hidden === true) {
                        this.open();
                    } else {
                        this.hide();
                    }
                    break;
                case 'xs':
                    if (hidden === true) {
                        this.open();
                    } else {
                        this.hide();
                    }
                    break;
            }

            // Re-init sliding menu to update width
            this.drillDownMenu(currentBreakpoint.name);
        },

        update: function update() {
            this.manualScroller.update();
        },

        reset: function reset() {
            this.expanded = false;
            this.collapsed = false;
            this.hidden = false;
            $body.removeClass('menu-hide menu-open menu-collapsed menu-expanded');
        }
    };

    // Navigation Menu
    $.app.nav = {
        container: $('.navigation-main'),
        initialized: false,
        navItem: $('.navigation-main').find('li').not('.navigation-category'),

        config: {
            speed: 300
        },

        init: function init(config) {
            this.initialized = true; // Set to true when initialized
            $.extend(this.config, config);

            if (!$body.is('.vertical-mmenu')) {
                this.bind_events();
            }
        },

        bind_events: function bind_events() {
            var menuObj = this;

            $('.navigation-main').on('mouseenter.app.menu', 'li', function () {
                var $this = $(this);
                $('.hover', '.navigation-main').removeClass('hover');
                if ($body.hasClass('menu-collapsed') || $body.data('menu') == 'vertical-compact-menu' && !$body.hasClass('vertical-overlay-menu')) {
                    $('.main-menu-content').children('span.menu-title').remove();
                    $('.main-menu-content').children('a.menu-title').remove();
                    $('.main-menu-content').children('ul.menu-content').remove();

                    // Title
                    var menuTitle = $this.find('span.menu-title').clone(),
                        tempTitle,
                        tempLink;
                    if (!$this.hasClass('has-sub')) {
                        tempTitle = $this.find('span.menu-title').text();
                        tempLink = $this.children('a').attr('href');
                        if (tempTitle !== '') {
                            menuTitle = $("<a>");
                            menuTitle.attr("href", tempLink);
                            menuTitle.attr("title", tempTitle);
                            menuTitle.text(tempTitle);
                            menuTitle.addClass("menu-title");
                        }
                    }
                    // menu_header_height = ($('.main-menu-header').length) ? $('.main-menu-header').height() : 0,
                    // fromTop = menu_header_height + $this.position().top + parseInt($this.css( "border-top" ),10);
                    var fromTop;
                    if ($this.css("border-top")) {
                        fromTop = $this.position().top + parseInt($this.css("border-top"), 10);
                    } else {
                        fromTop = $this.position().top;
                    }
                    if ($body.data('menu') !== 'vertical-compact-menu') {
                        menuTitle.appendTo('.main-menu-content').css({
                            position: 'fixed',
                            top: fromTop
                        });
                    }

                    // Content
                    if ($this.hasClass('has-sub') && $this.hasClass('nav-item')) {
                        var menuContent = $this.children('ul:first');
                        menuObj.adjustSubmenu($this);
                    }
                }
                $this.addClass('hover');
            }).on('mouseleave.app.menu', 'li', function () {
                // $(this).removeClass('hover');
            }).on('active.app.menu', 'li', function (e) {
                $(this).addClass('active');
                e.stopPropagation();
            }).on('deactive.app.menu', 'li.active', function (e) {
                $(this).removeClass('active');
                e.stopPropagation();
            }).on('open.app.menu', 'li', function (e) {

                var $listItem = $(this);
                $listItem.addClass('open');

                menuObj.expand($listItem);

                // If menu collapsible then do not take any action
                if ($('.main-menu').hasClass('menu-collapsible')) {
                    return false;
                }
                // If menu accordion then close all except clicked once
                else {
                        $listItem.siblings('.open').find('li.open').trigger('close.app.menu');
                        $listItem.siblings('.open').trigger('close.app.menu');
                    }

                e.stopPropagation();
            }).on('close.app.menu', 'li.open', function (e) {
                var $listItem = $(this);

                $listItem.removeClass('open');
                menuObj.collapse($listItem);

                e.stopPropagation();
            }).on('click.app.menu', 'li', function (e) {
                var $listItem = $(this);
                if ($listItem.is('.disabled')) {
                    e.preventDefault();
                } else {
                    if ($body.hasClass('menu-collapsed') || $body.data('menu') == 'vertical-compact-menu' && $listItem.is('.has-sub') && !$body.hasClass('vertical-overlay-menu')) {
                        e.preventDefault();
                    } else {
                        if ($listItem.has('ul')) {
                            if ($listItem.is('.open')) {
                                $listItem.trigger('close.app.menu');
                            } else {
                                $listItem.trigger('open.app.menu');
                            }
                        } else {
                            if (!$listItem.is('.active')) {
                                $listItem.siblings('.active').trigger('deactive.app.menu');
                                $listItem.trigger('active.app.menu');
                            }
                        }
                    }
                }

                e.stopPropagation();
            });

            $('.main-menu-content').on('mouseleave', function () {
                if ($body.hasClass('menu-collapsed') || $body.data('menu') == 'vertical-compact-menu') {
                    $('.main-menu-content').children('span.menu-title').remove();
                    $('.main-menu-content').children('a.menu-title').remove();
                    $('.main-menu-content').children('ul.menu-content').remove();
                }
                $('.hover', '.navigation-main').removeClass('hover');
            });

            // If list item has sub menu items then prevent redirection.
            $('.navigation-main li.has-sub > a').on('click', function (e) {
                e.preventDefault();
            });

            $('ul.menu-content').on('click', 'li', function (e) {
                var $listItem = $(this);
                if ($listItem.is('.disabled')) {
                    e.preventDefault();
                } else {
                    if ($listItem.has('ul')) {
                        if ($listItem.is('.open')) {
                            $listItem.removeClass('open');
                            menuObj.collapse($listItem);
                        } else {
                            $listItem.addClass('open');

                            menuObj.expand($listItem);

                            // If menu collapsible then do not take any action
                            if ($('.main-menu').hasClass('menu-collapsible')) {
                                return false;
                            }
                            // If menu accordion then close all except clicked once
                            else {
                                    $listItem.siblings('.open').find('li.open').trigger('close.app.menu');
                                    $listItem.siblings('.open').trigger('close.app.menu');
                                }

                            e.stopPropagation();
                        }
                    } else {
                        if (!$listItem.is('.active')) {
                            $listItem.siblings('.active').trigger('deactive.app.menu');
                            $listItem.trigger('active.app.menu');
                        }
                    }
                }

                e.stopPropagation();
            });
        },

        /**
         * Ensure an admin submenu is within the visual viewport.
         * @param {jQuery} $menuItem The parent menu item containing the submenu.
         */
        adjustSubmenu: function adjustSubmenu($menuItem) {
            var menuHeaderHeight,
                menutop,
                topPos,
                winHeight,
                bottomOffset,
                subMenuHeight,
                popOutMenuHeight,
                borderWidth,
                scroll_theme,
                $submenu = $menuItem.children('ul:first'),
                ul = $submenu.clone(true);

            menuHeaderHeight = $('.main-menu-header').height();
            menutop = $menuItem.position().top;
            winHeight = $window.height() - $('.header-navbar').height();
            borderWidth = 0;
            subMenuHeight = $submenu.height();

            if (parseInt($menuItem.css("border-top"), 10) > 0) {
                borderWidth = parseInt($menuItem.css("border-top"), 10);
            }

            popOutMenuHeight = winHeight - menutop - $menuItem.height() - 30;
            scroll_theme = $('.main-menu').hasClass('menu-dark') ? 'light' : 'dark';

            if ($body.data('menu') === 'vertical-compact-menu') {
                topPos = menutop + borderWidth;
                popOutMenuHeight = winHeight - menutop - 30;
            } else if ($body.data('menu') === 'vertical-content-menu') {
                topPos = menutop + $menuItem.height() + borderWidth;
                popOutMenuHeight = winHeight - $('.content-header').height() - $menuItem.height() - menutop - 60;
            } else {
                topPos = menutop + $menuItem.height() + borderWidth;
            }

            if ($body.data('menu') == 'vertical-content-menu') {
                ul.addClass('menu-popout').appendTo('.main-menu-content').css({
                    'top': topPos,
                    'position': 'fixed'
                });
            } else {
                ul.addClass('menu-popout').appendTo('.main-menu-content').css({
                    'top': topPos,
                    'position': 'fixed',
                    'max-height': popOutMenuHeight
                });

                $('.main-menu-content > ul.menu-content').perfectScrollbar({
                    theme: scroll_theme
                });
            }
        },

        collapse: function collapse($listItem, callback) {
            var $subList = $listItem.children('ul');

            $subList.show().slideUp($.app.nav.config.speed, function () {
                $(this).css('display', '');

                $(this).find('> li').removeClass('is-shown');

                if (callback) {
                    callback();
                }

                $.app.nav.container.trigger('collapsed.app.menu');
            });
        },

        expand: function expand($listItem, callback) {
            var $subList = $listItem.children('ul');
            var $children = $subList.children('li').addClass('is-hidden');

            $subList.hide().slideDown($.app.nav.config.speed, function () {
                $(this).css('display', '');

                if (callback) {
                    callback();
                }

                $.app.nav.container.trigger('expanded.app.menu');
            });

            setTimeout(function () {
                $children.addClass('is-shown');
                $children.removeClass('is-hidden');
            }, 0);
        },

        refresh: function refresh() {
            $.app.nav.container.find('.open').removeClass('open');
        }
    };
})(window, document, jQuery);

/***/ }),

/***/ 174:
/***/ (function(module, exports) {

$("#adminSigninForm").validate({
    rules: {
        adminSigninEmail: {
            required: true,
            email: true
        },
        adminSigninPassword: {
            required: true,
            minlength: 5,
            maxlength: 20

        }
    },
    messages: {
        adminSigninEmail: {
            required: "E-Mail is required"
        },
        adminSigninPassword: {
            required: "Password is required",
            minlength: "Password must be at least 5 characters",
            remote: "Password must be no more than 20 characters"
        }
    },

    // SignUp Submit Handler
    submitHandler: function submitHandler(form, e) {

        var adminSigninEmails = $("#adminSigninEmail").val();
        var adminSigninPasswords = $("#adminSigninPassword").val();
        e.preventDefault();
        var form = $('#adminSigninForm');
        $.ajax({
            type: "POST",
            url: "/login",
            data: form.serialize(),
            dataType: 'json',
            beforeSend: function beforeSend() {

                $('.ajax-loading').css('display', 'block');
            },
            complete: function complete() {

                $('.ajax-loading').css('display', 'none');
            },
            success: function success(data) {

                window.location.href = "/admin/home";
            },
            error: function error(data) {

                window.location.href = "/";
            }

        });
    }

});

$('.forget-password-link a').on('click', function () {

    $('#all-admin-signin-data').css('display', 'none');

    $('#forget-password-admin-signin').css('display', 'block');
});

$('#forget-password-back').on('click', function () {

    $('#forget-password-admin-signin').css('display', 'none');

    $('#all-admin-signin-data').css('display', 'block');
});

$('#adminShowPassword').on('click', function () {

    var adminShowPasswordInput = document.getElementById("adminSigninPassword");

    if (adminShowPasswordInput.type === "password") {
        $('#adminShowPassword').text("Hide password");
        adminShowPasswordInput.type = "text";
    } else {

        $('#adminShowPassword').text("Show password");
        adminShowPasswordInput.type = "password";
    }
});

//forget password validation


$("#forget-password-admin-signin").validate({
    rules: {
        adminForgetPasswordEmail: {
            required: true,
            email: true
        }
    },
    messages: {
        adminForgetPasswordEmail: {
            required: "E-Mail is required"
        }
    },

    // SignUp Submit Handler
    submitHandler: function submitHandler(form, e) {

        var url = "path/to/your/script.php"; // the script where you handle the form input.

        var adminForgetPasswordEmail = $("#adminForgetPasswordEmail").val();

        $.ajax({
            type: "POST",
            url: url,
            beforeSend: function beforeSend() {

                $('.ajax-loading').css('display', 'block');
            },
            complete: function complete() {

                $('.ajax-loading').css('display', 'none');
            },
            success: function success(data) {

                Swal('Hello world!');
            },
            error: function error(data) {
                window.location.href = "/password-reset";
            }

        });

        e.preventDefault();
    }

});

/***/ })

/******/ });