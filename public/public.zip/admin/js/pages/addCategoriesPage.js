/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 189);
/******/ })
/************************************************************************/
/******/ ({

/***/ 189:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(190);


/***/ }),

/***/ 190:
/***/ (function(module, exports) {

$("#addCategoryForm").validate({
    rules: {
        adminsCategory: {
            required: true

        },
        adminsSubCategory: {
            required: false
        }

    },
    messages: {
        adminsCategory: {
            required: "Category name is required"
        }
    },

    // SignUp Submit Handler
    submitHandler: function submitHandler(form, e) {

        var url = "/admin/add-categories"; // the script where you handle the form input.


        var adminsCategory = $("#adminsCategory").val();
        var adminsSubCategory = $("#adminsSubCategory").val();
        e.preventDefault();
        var form = $('#addCategoryForm');
        $.ajax({
            type: "POST",
            url: url,
            data: form.serialize(),
            dataType: 'json',
            beforeSend: function beforeSend() {

                $('.ajax-loading').css('display', 'block');
            },
            complete: function complete() {

                $('.ajax-loading').css('display', 'none');
            },
            success: function success(data) {
                if (data == 'category added successfully') {
                    Swal({
                        title: "Successfully added " + adminsCategory + " to Categories",
                        type: 'success',
                        animation: true,
                        showCancelButton: true,
                        confirmButtonText: 'See All Categories',
                        cancelButtonText: 'Add Other Categories',
                        confirmButtonClass: 'zidni-confirm',
                        cancelButtonClass: 'zidni-cancel',
                        allowOutsideClick: true,
                        allowEscapeKey: true,
                        width: '60rem',
                        customClass: 'welcomeAlertMessage'
                    }).then(function (result) {
                        if (result.value) {
                            window.location.href = "/admin/all-categories";
                        } else {

                            var _adminsCategory = $("#adminsCategory").val('');
                            var _adminsSubCategory = $("#adminsSubCategory").val('');
                        }
                    });
                } else {
                    Swal({
                        title: data,
                        type: 'success',
                        animation: true,
                        showCancelButton: true,
                        confirmButtonText: 'See All Categories',
                        cancelButtonText: 'Add Other Categories',
                        confirmButtonClass: 'zidni-confirm',
                        cancelButtonClass: 'zidni-cancel',
                        allowOutsideClick: true,
                        allowEscapeKey: true,
                        width: '60rem',
                        customClass: 'welcomeAlertMessage'
                    }).then(function (result) {
                        if (result.value) {
                            window.location.href = "/admin/all-categories";
                        } else {

                            var _adminsCategory2 = $("#adminsCategory").val('');
                            var _adminsSubCategory2 = $("#adminsSubCategory").val('');
                        }
                    });
                }
            },
            error: function error(data) {

                console.log('error');
            }

        });
    }

});

/***/ })

/******/ });