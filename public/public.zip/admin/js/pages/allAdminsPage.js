/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 179);
/******/ })
/************************************************************************/
/******/ ({

/***/ 179:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(180);


/***/ }),

/***/ 180:
/***/ (function(module, exports) {



var allAdminsTable = $('#allAdminsTable');

allAdminsTable.DataTable({
    "dom": "<'row'<'col-md-6 tabel-option'B><'col-md-6 tabel-search'f><'col-md-6 table-info'i><'col-md-6 table-lenght'l>>" + "<'row'<'col-md-12 table-container't>><'row'<'col-md-12 table-pag'p>>",
    "paging": true,
    "ordering": true,
    "autoWidth": true,
    responsive: false,
    "scrollX": true,
    buttons: [{
        extend: 'collection',
        text: 'All Admins Options',

        buttons: [{
            extend: 'copyHtml5',
            text: 'Copy All Admins',
            exportOptions: {
                columns: [1, 2, 3, 4]
            }

        }, {
            extend: 'csvHtml5',
            text: 'Download Csv File',
            exportOptions: {
                columns: [1, 2, 3, 4]
            }
        }, {
            extend: 'excelHtml5',
            text: 'Download Excel File',
            exportOptions: {
                columns: [1, 2, 3, 4]
            }
        }, {
            extend: 'print',
            text: 'Print',
            exportOptions: {
                bHeader: "Zidni Admins",
                columns: [1, 2, 3, 4]
            }
        }, {
            extend: 'selectAll',
            text: 'Select All Admins'
        }, {
            extend: 'selectNone',
            text: 'Unselect All Admins'
        }]
    }],
    columnDefs: [{
        orderable: false,
        className: 'select-checkbox',
        targets: 0
    }, {
        targets: 1,
        "width": "15%"
    }, {
        targets: 2,
        "width": "25%"
    }],
    select: {
        style: 'multi',
        selector: 'td:first-child'
    },
    order: [[1, 'asc']]
});

$('#allAdminsTableContainer .buttons-collection').on('click', function () {

    $('#allAdminsTableContainer .dt-button-collection').append('<button id="table-delete" class="btn" tabindex="0" aria-controls="postsTable"><span>Delete Selected Admins</span></button>');

    if ($("tr").hasClass("selected")) {

        $('#allAdminsTableContainer #table-delete').removeAttr('disabled');
    } else {

        $('#allAdminsTableContainer #table-delete').prop("disabled", true);
    };

    $('#allAdminsTableContainer .buttons-select-all').click(function () {

        $('#allAdminsTableContainer #table-delete').removeAttr('disabled');
    });

    $('#allAdminsTableContainer .buttons-select-none').click(function () {

        $('#allAdminsTableContainer #table-delete').prop("disabled", true);
    });

    $('.buttons-colvis').click(function () {

        $("#table-delete").remove();
    });

    $('.dt-button-background').click(function () {

        $("#table-delete").remove();
    });

    $('#allAdminsTableContainer #table-delete').click(function () {

        swal({
            title: 'هل انت متأكد من مسح جميع الصفوف المختارة',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'مسح',
            cancelButtonText: 'إلغاء',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger',
            buttonsStyling: false,
            reverseButtons: false
        }).then(function (result) {

            if (result.value) {

                swal({

                    type: 'success',
                    title: 'تم المسح بنجاح',
                    showConfirmButton: false,
                    timer: 2500

                });

                if ($("#allAdminsTable tr").hasClass("selected")) {

                    $("#allAdminsTable tr.selected").remove();
                    $("#table-delete").remove();
                }

                console.log(1);
            } else if (
            // Read more about handling dismissals
            result.dismiss === swal.DismissReason.cancel) {
                swal({

                    type: 'error',
                    title: 'تم إلغاء الحذف',
                    showConfirmButton: false,
                    timer: 2500

                });

                $("#table-delete").remove();
            }
        });
    });
});

/***/ })

/******/ });