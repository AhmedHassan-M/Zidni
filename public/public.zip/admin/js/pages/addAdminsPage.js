/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 181);
/******/ })
/************************************************************************/
/******/ ({

/***/ 181:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(182);


/***/ }),

/***/ 182:
/***/ (function(module, exports) {

$("#addAdminsForm").validate({
    rules: {
        adminsFullName: {
            required: true

        },
        adminsEmail: {
            required: true,
            email: true

        },
        adminsPassword: {
            required: true,
            minlength: 5,
            maxlength: 20

        },
        adminsRetypePassword: {
            required: true,
            minlength: 5,
            maxlength: 20,
            equalTo: "#adminsPassword"

        },
        adminsRoles: {
            required: true

        }
    },
    messages: {
        adminsFullName: {
            required: "Enter Admin FullName"
        },

        adminsRetypePassword: {
            required: "Password is required",
            minlength: "Password must be at least 5 characters",
            remote: "Password must be no more than 20 characters"
        },
        adminsPassword: {
            required: "Password is required",
            minlength: "Password must be at least 5 characters",
            remote: "Password must be no more than 20 characters"
        },
        adminsRoles: {
            required: "Select Admin Role"
        }

    },

    // SignUp Submit Handler
    submitHandler: function submitHandler(form, e) {

        var url = "path/to/your/script.php"; // the script where you handle the form input.

        var adminsFullName = $("#adminsFullName").val();
        var adminsEmail = $("#adminsEmail").val();
        var adminsPassword = $("#adminsPassword").val();
        var adminsRetypePassword = $("#adminsRetypePassword").val();
        var adminsRoles = $("#adminsRoles").val();

        $.ajax({
            type: "POST",
            url: url,
            beforeSend: function beforeSend() {

                $('.ajax-loading').css('display', 'block');
            },
            complete: function complete() {

                $('.ajax-loading').css('display', 'none');
            },
            success: function success(data) {},
            error: function error(data) {

                Swal({
                    title: "Successfully added " + adminsFullName + " as " + adminsRoles + " to Zidni institute ",
                    imageUrl: 'http://placehold.it/150x150',
                    imageWidth: 150,
                    imageHeight: 150,
                    imageAlt: 'Zidni Logo',
                    animation: true,
                    showCancelButton: false,
                    confirmButtonColor: '#f1dd7e',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'See All Admins',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    width: '60rem',
                    customClass: 'welcomeAlertMessage'
                }).then(function (result) {
                    if (result.value) {
                        window.location.href = "/admin/home/all-admins";
                    }
                });
            }

        });

        e.preventDefault();
    }

});

$('#newAdminShowPassword').on('click', function () {

    var newAdminShowPassword = document.getElementById("adminsPassword");

    if (newAdminShowPassword.type === "password") {
        $('#newAdminShowPassword').text("Hide password");
        newAdminShowPassword.type = "text";
    } else {

        $('#newAdminShowPassword').text("Show password");
        newAdminShowPassword.type = "password";
    }
});

/***/ })

/******/ });