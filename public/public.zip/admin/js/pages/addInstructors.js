/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 218);
/******/ })
/************************************************************************/
/******/ ({

/***/ 218:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(219);


/***/ }),

/***/ 219:
/***/ (function(module, exports) {


$(document).ready(function () {

    var addInstructorsForm = $('#addInstructorsForm');

    addInstructorsForm.validate({
        rules: {
            instructorsFullName: {
                required: true

            },
            instructorsOverview: {
                required: true,
                minlength: 5,
                maxlength: 1000

            },
            instructorsPhoto: {

                required: true

            },
            instructorsFacebook: {

                url: true

            },
            instructorsTwitter: {

                url: true

            },
            instructorsLinkedin: {

                url: true

            }
        },
        messages: {
            instructorsFullName: {
                required: "Instructors FullName is required"
            },

            instructorsOverview: {
                required: "Instructors Overview is required"
            },
            instructorsPhoto: {
                required: "instructors Photo is required"
            }
        },

        // SignUp Submit Handler
        submitHandler: function submitHandler(form, e) {

            var url = "path/to/your/script.php"; // the script where you handle the form input.

            var instructorsFullName = $("#instructorsFullName").val();
            var instructorsOverview = $("#instructorsOverview").val();
            var instructorsPhoto = $('#instructorsPhoto').prop('files')[0];
            var instructorsFacebook = $("#instructorsFacebook").val();
            var instructorsTwitter = $("#instructorsTwitter").val();
            var instructorsLinkedin = $("#instructorsLinkedin").val();

            e.preventDefault();
            var instructorForm = $('.instructor-form');

            var form_data = new FormData();
            form_data.append('fullname', instructorsFullName);
            form_data.append('overview', instructorsOverview);
            form_data.append('photo', instructorsPhoto);
            form_data.append('fb', instructorsFacebook);
            form_data.append('twit', instructorsTwitter);
            form_data.append('ln', instructorsLinkedin);

            $.ajax({
                type: "POST",
                url: "/admin/add-instructors",
                data: form_data,
                contentType: false, // The content type used when sending data to the server.
                cache: false, // To unable request pages to be cached
                processData: false,
                beforeSend: function beforeSend() {

                    $('.ajax-loading').css('display', 'block');
                },
                complete: function complete() {

                    $('.ajax-loading').css('display', 'none');
                },
                success: function success(data) {
                    console.log(data);

                    Swal({
                        title: "Successfully added " + instructorsFullName + " to Zidni Instructors ",
                        imageUrl: 'http://placehold.it/150x150',
                        imageWidth: 150,
                        imageHeight: 150,
                        imageAlt: 'Zidni Logo',
                        animation: true,
                        showCancelButton: false,
                        confirmButtonColor: '#f1dd7e',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'See All Instructors',
                        allowOutsideClick: true,
                        allowEscapeKey: true,
                        width: '60rem',
                        customClass: 'welcomeAlertMessage'
                    }).then(function (result) {
                        if (result.value) {

                            window.location.href = "/admin/all-instructors";
                        } else {
                            var _instructorsFullName = $("#instructorsFullName").val('');
                            var _instructorsOverview = $("#instructorsOverview").val('');
                            $('.dropify-clear').click();
                            var _instructorsFacebook = $("#instructorsFacebook").val('');
                            var _instructorsTwitter = $("#instructorsTwitter").val('');
                            var _instructorsLinkedin = $("#instructorsLinkedin").val('');
                        }
                    });
                },
                error: function error(data) {}

            });

            e.preventDefault();
        }

    });

    $('.dropify').dropify({

        messages: {
            'default': 'Drag and drop a instructor image here or click',
            'replace': 'Drag and drop or click to replace instructor image',
            'remove': 'Remove',
            'error': 'Ooops, something wrong happended.',
            'test': 'Your image should be at minimum 200x200 pixels and maximum 1000x1000 pixels'

        },
        tpl: {
            wrap: '<div class="dropify-wrapper"></div>',
            loader: '<div class="dropify-loader"></div>',
            message: '<div class="dropify-message"><span class="file-icon" /> <p>{{ default }}</p></div>',
            preview: '<div class="dropify-preview"><span class="dropify-render"></span><div class="dropify-infos"><div class="dropify-infos-inner"><p class="dropify-infos-message">{{ replace }}</p><p class="dropify-infos-message">{{ test }}</p></div></div></div>',
            filename: '<p class="dropify-filename"><span class="file-icon"></span> <span class="dropify-filename-inner"></span></p>',
            clearButton: '<button type="button" class="dropify-clear">{{ remove }}</button>',
            errorLine: '<p class="dropify-error">{{ error }}</p>',
            errorsContainer: '<div class="dropify-errors-container"><ul></ul></div>'
        },
        error: {
            'fileSize': 'The file size is too big ( {{ value }} max ).',
            'minWidth': 'The image width is too small ( {{ value }} px min ).',
            'maxWidth': 'The image width is too big ( {{ value }} px max ).',
            'minHeight': 'The image height is too small ( {{ value }} px min ).',
            'maxHeight': 'The image height is too big ( {{ value }}px max ).',
            'imageFormat': 'The image format is not allowed ( {{ value }} only ).'
        }

    });
});

/***/ })

/******/ });