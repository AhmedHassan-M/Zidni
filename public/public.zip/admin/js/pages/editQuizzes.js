/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 214);
/******/ })
/************************************************************************/
/******/ ({

/***/ 214:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(215);


/***/ }),

/***/ 215:
/***/ (function(module, exports) {


$(document).ready(function () {

    var EditQuizzesForm = $("#EditQuizzesForm");

    EditQuizzesForm.validate({

        rules: {
            editQuizzesCategory: {
                required: true
            },
            editQuizzesName: {
                required: true,
                minlength: 3,
                maxlength: 30
            },
            editQuizzesPassingScore: {
                required: true
            }
        },
        messages: {
            editQuizzesCategory: {
                required: "Quiz Category is required"
            },
            editQuizzesName: {
                required: "Quiz Name is required"
            },
            editQuizzesPassingScore: {
                required: "Quiz Passing Score is required"
            }
        }
    });

    $('.popover-info').popover();

    // Question Counter


    var questionsCounter = $('.quizQuestionsContainer').length;

    $('#quizQuestionsCounter span').html(questionsCounter);

    // Total Score Counter

    function calculateSum() {

        var sum = 0;
        //iterate through each textboxes and add the values
        $(".quiz-questions-score").each(function () {

            //add only if the value is number
            if (!isNaN(this.value) && this.value.length != 0) {
                sum += parseFloat(this.value);
            }
        });
        //.toFixed() method will roundoff the final sum to 2 decimal places
        $("#totalScoreCounter span").html(sum);
    }

    calculateSum();

    //iterate through each textboxes and add keyup
    //handler to trigger sum event
    $(".quiz-questions-score").each(function () {

        $(this).keyup(function () {
            calculateSum();
        });
    });

    // Add More Answers


    $(document).on('click', '.addMoreAnswers', function () {

        var cloneAnswersFromQuestion = $(this).parent().find('fieldset .form-check').first().clone();

        cloneAnswersFromQuestion.find(".quiz-questions-correct-answers").prop('checked', false);

        cloneAnswersFromQuestion.find(".quiz-questions-answers-title").val('');

        cloneAnswersFromQuestion.addClass('moreAnswers');

        var maxAnswersLimit = $(this).parent().find('fieldset .form-check');

        if (maxAnswersLimit.length < 5) {

            $(this).parent().find('fieldset').append(cloneAnswersFromQuestion.fadeIn());
        }
    });

    // Answer Delete Icon


    $(document).on('click', '.quizAnswerDelete', function () {

        $(this).parent().remove();
    });

    // Quiz Questions Delete

    $(document).on('click', '.quizQuestionsDelete', function () {

        var deleteQuestion = $(this).parent().parent().parent().parent();

        swal({
            title: 'Are you sure you want to delete this Question?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel'
        }).then(function (result) {
            if (result.value) {

                swal({
                    title: 'Question successfully deleted',
                    type: 'success',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'Good',
                    confirmButtonClass: 'btn btn-success'
                });

                deleteQuestion.remove();
                var _questionsCounter = $('.quizQuestionsContainer').length;

                $('#quizQuestionsCounter span').html(_questionsCounter);

                calculateSum();
            }
        });
    });

    //select2


    $('.form-select-active').select2();

    $('.form-select-active').select2().change(function () {
        $(this).valid();
    });
});

/***/ })

/******/ });