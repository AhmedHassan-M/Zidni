/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 196);
/******/ })
/************************************************************************/
/******/ ({

/***/ 196:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(197);


/***/ }),

/***/ 197:
/***/ (function(module, exports) {



$(document).ready(function () {

    var EditCoursesForm = $("#EditCoursesForm");
    var summernoteElement = $('#Overview');

    $('#addPrice').priceFormat();

    //select2


    $('.form-select-active').select2();

    $('.form-select-active').select2().change(function () {
        $(this).valid();
    });

    // This will set `ignore` for all validation calls
    jQuery.validator.setDefaults({
        // This will ignore all hidden elements alongside `contenteditable` elements
        // that have no `name` attribute
        ignore: ":hidden, [contenteditable='true']:not([name])"

    });

    EditCoursesForm.validate({

        rules: {
            courseName: {
                required: true,
                minlength: 3,
                maxlength: 30

            },
            selectCategory: {

                required: true

            },
            shortDescription: {

                required: true,
                minlength: 3,
                maxlength: 300
            },
            selectInstructor: {

                required: true

            },
            previewVideo: {

                required: true,
                url: true

            },
            addPrice: {

                required: true

            },
            totalDuration: {
                required: true
            },
            addLanguage: {
                required: true
            },
            'lessonName[]': {
                required: true
            }

        },
        messages: {
            courseName: {
                required: "Course name is required"
            },
            selectCategory: {
                required: "Category is required"
            },
            shortDescription: {
                required: "Short description is required"
            },
            selectInstructor: {

                required: "Instructor is required"

            },
            previewVideo: {

                required: "Preview video is required"

            },
            addPrice: {

                required: "Price is required"

            },
            totalDuration: {

                required: "Total duration is required"

            },
            addLanguage: {

                required: "Language is required"

            }

        }

    });

    summernoteElement.summernote({

        tabsize: 2,
        height: 400,
        toolbar: [['style', ['style']], ['font', ['bold', 'italic', 'underline', 'clear']], ['color', ['color']], ['para', ['ul', 'ol', 'paragraph']], ['height', ['height']], ['insert', ['link', 'hr']]],
        disableResizeEditor: true
    });

    $('.note-statusbar').hide();

    // const MoreFieldInputs1 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_1[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_1[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'

    // const MoreFieldInputs2 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_2[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_2[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs3 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_3[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_3[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs4 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_4[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_4[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs5 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_5[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_5[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs6 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_6[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_6[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs7 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_7[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_7[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs8 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_8[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_8[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs9 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_9[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_9[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs10 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_10[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_10[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs11 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_11[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_11[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    // const MoreFieldInputs12 = '<div class="weekLessonContainer"><div class="form-group"> <label for="LessonName">Lesson Name</label> <input type="text" class="form-control week-lesson-name" name="LessonName_12[]" /></div><div class="form-group "> <label for="LessonLink">Lesson link</label> <input type="text" class="form-control week-lesson-link" name="LessonLink_12[]" /></div> <a class="previewInputLink" target="_blank"><i class="fas fa-eye"></i></a> <a class="deleteInputRow"><i class="far fa-trash-alt"></i></a></div>'


    var $template = $(".week-card:first");

    var cardHeader = 6;
    var dataTarget = 6;
    var ariaControls = 6;
    var weekContentId = 6;
    var ariaLabelledby = 6;
    var weekCounterText = 6;

    // form inputs


    var weekTitle = 6;
    var weekLessonName = 6;
    var weekLessonLink = 6;

    var addMoreLesson = 6;

    //limit the weeks


    var numberOfWeeks = 6;

    var maxNumberOfWeeks = 12; //Input fields increment limitation

    // Start Append


    var weeksWrapper = $('.weekLessonWrapper');

    var lastWeekCount = parseFloat($('.week-card').last().data('week'));

    console.log(lastWeekCount);

    $(".addMoreWeeks").on("click", function () {

        lastWeekCount++; //Increment field counter


        var $newPanel = $template.clone();

        $newPanel.attr("data-week", lastWeekCount);

        $newPanel.find(".card-header").attr("id", "week_header_" + lastWeekCount);
        $newPanel.find(".btn-link").attr("data-target", "#week_target_" + lastWeekCount);
        $newPanel.find(".btn-link").attr("aria-controls", "week_target_" + lastWeekCount);
        // $newPanel.find(".btn-link").text("Week #" + (++weekCounterText));
        $newPanel.find(".week-content").attr("id", "week_target_" + lastWeekCount);
        $newPanel.find(".week-content").attr("aria-labelledby", "week_header_" + lastWeekCount);

        //form inputs append

        $newPanel.find(".week-name-title").attr("name", "weekName_" + lastWeekCount);
        $newPanel.find(".week-lesson-name").attr("name", "LessonName_" + lastWeekCount + "[]");
        $newPanel.find(".week-lesson-link").attr("name", "LessonLink_" + lastWeekCount + "[]");

        $newPanel.find(".card-header button span").text('Week Title');

        //form inputs femove values


        $newPanel.find(".week-name-title").val('');
        $newPanel.find(".week-lesson-name").val('');
        $newPanel.find(".week-lesson-link").val('');

        // remove weekLessonWrapper
        $newPanel.find(".weekLessonWrapper *").remove();

        $("#accordion").append($newPanel.fadeIn());
    });

    // update the week names

    $(document).on('click', '.courseLessonsNavContainer', function () {

        var currentWeekName = $('.weekNameContainer input').val();

        $('.weekNameContainer input').parent().parent().parent().parent().parent().find('.btn-link span').html(currentWeekName);
    });

    // keyup traker

    $(document).on('keyup', '.week-name-title', function () {

        $(this).parent().parent().parent().parent().parent().find('.btn-link span').html($(this).val());
    });

    // Delete Button

    $(document).on('click', '.deleteInputRow', function () {
        var _this = this;

        swal({
            title: 'Are you sure you want to delete this Lesson?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then(function (result) {
            if (result.value) {
                $(_this).parent().remove();
            }
        });
    });

    // Add Exist Lesson URL

    $(document).on('click', '.previewInputLink', function () {

        var ExistLessonUrl = $(this).parent().find('.week-lesson-link').val();

        $(this).attr("href", ExistLessonUrl);
    });

    // Add More Lessons


    $(document).on('click', '.addOtherLessonsButton', function () {

        var CurrentWeekLessonsTest = $(this).parent().parent().parent().find('.weekLessonContainer:first').clone();

        CurrentWeekLessonsTest.find(".week-lesson-name").val('');
        CurrentWeekLessonsTest.find(".week-lesson-link").val('');

        $(this).parent().parent().parent().find('.weekLessonWrapper').append(CurrentWeekLessonsTest);
    });

    // Add Lesson URL

    $(document).on('keyup touchend input', '.week-lesson-link', function () {

        var currentLessonUrl = $(this).val();

        $(this).parent().parent().find('.previewInputLink').attr("href", currentLessonUrl);
    });

    $(document).on('click', '.deleteWeekButton', function () {
        var _this2 = this;

        swal({
            title: 'Are you sure you want to delete this week?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then(function (result) {
            if (result.value) {
                swal('Deleted!', 'This week has been deleted.', 'success');

                $(_this2).parents('.week-card').remove();
            }
        });
    });
});

/***/ })

/******/ });